﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework.Internal
{
    public interface IResetable
    {
        void Reset();
    }
}