﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework.Internal
{
    /// <summary>
    /// 作为数据结构是一个节点
    /// </summary>
    public interface INode
    {
        
    }

    /// <summary>
    /// 需要有个容器
    /// </summary>
    public interface INodeContainer
    {
        
    }
}