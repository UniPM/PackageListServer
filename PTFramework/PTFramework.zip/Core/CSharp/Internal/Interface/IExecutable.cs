﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework.Internal
{
    /// <summary>
    /// 可执行的 有三个周期
    /// </summary>
    public interface IExecutable
    {
        bool Execute();
    }
    
    public interface IExecutable<T>
    {
        bool Execute(T arg);
    }
}