﻿/****************************************************************************
 * Copyright (c) 2017 yuanhuibin@putao.com
 ****************************************************************************/

namespace PTGame.Framework.Test.Core
{
    using NUnit.Framework;
    
    public class EventSystemTest
    {
        [Test]
        public void EventSystemTest_Register()
        {
            int key = 10000;
            int registerCount = 0;
            bool rigisters1 = PTEventSystem.Instance.Register(key, delegate
            {
                registerCount++;
            });
            PTEventSystem.Instance.Send(key);
            Assert.AreEqual(1, registerCount);
            bool rigisters2 = PTEventSystem.Instance.Register(key, delegate
            {
                registerCount++;
            });
            PTEventSystem.Instance.Send(key);
            Assert.AreEqual(3, registerCount);
        }

        [Test]
        public void EventSystemTest_UnRegister()
        {
            int key = 20000;
            int registerCount = 0;
            bool rigisters = PTEventSystem.Instance.Register(key, delegate
            {
                registerCount++;
            });
            PTEventSystem.Instance.Send(key);
            Assert.AreEqual(1, registerCount);
            PTEventSystem.Instance.UnRegister(key, delegate
            {
                registerCount--;
            });
            Assert.AreEqual(1, registerCount);
        }

        [Test]
        public void EventSystemTest_Send()
        {
            int key = 30000;
            int registerCount = 0;
            bool rigisters = PTEventSystem.Instance.Register(key, delegate
            {
                registerCount++;
            });
            bool sendValue = true;
            bool backValue = PTEventSystem.Instance.Send(key);
            Assert.AreEqual(sendValue, backValue);
        }
    }
}