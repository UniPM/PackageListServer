﻿/****************************************************************************
 * Copyright (c) 2017 xiaojun@putao.com
 * Copyright (c) 2017 liqingyun@putao.com
****************************************************************************/

using UnityEngine.Assertions;

namespace PTGame.Framework
{
	using UnityEngine;

	[PTMonoSingletonAttribute("[Event]/PTMsgCenter")]
	public partial class PTMsgCenter : MonoBehaviour, ISingleton
	{
		public static PTMsgCenter Instance
		{
			get { return PTMonoSingletonProperty<PTMsgCenter>.Instance; }
		}

		public void OnSingletonInit()
		{

		}

		public void Dispose()
		{
			PTMonoSingletonProperty<PTMsgCenter>.Dispose();
		}

		void Awake()
		{
			DontDestroyOnLoad(this);
		}

		public void SendMsg(PTMsg tmpMsg)
		{
			// Framework Msg
			switch (tmpMsg.GetMgrID())
			{
				case PTMgrID.UI:
					PTUIManager.Instance.SendMsg(tmpMsg);
					return;
				case PTMgrID.Audio:
					AudioManager.Instance.SendMsg(tmpMsg);
					return;
				case PTMgrID.PCConnectMobile:
					PCConnectMobileManager.Instance.SendMsg(tmpMsg);
					return;
			}

			Log.E("使用消息之前要取消掉这个注释");
//			ForwardMsg(tmpMsg);
		}
	}
}