﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

using System.Collections.Generic;
using UnityEngine;
using NUnit.Framework;
using PTGame.Framework;

public class LanguageTest 
{
	[Test]
	public void EditorTest() 
	{
		//Arrange
		var gameObject = new GameObject();
		Debug.Log(System.Environment.Version);
		//Act
		//Try to rename the GameObject
		var newGameObjectName = "My game object";
		gameObject.name = newGameObjectName;

		//Assert
		//The object has a new name
		Assert.AreEqual(newGameObjectName, gameObject.name);
//		OK();	
		// 匿名类测试
		var a = new { Name = "rock",Age = 123,TodoList = new List<int> {1,2,3,4}};
		
		Log.i(a.Name);
		Log.i(a.Age);
	}
}
