﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework.CodeGeneration.CodeGenerator.CLI
{
    using PTGame.Framework;

    public class DryRun : ECSCommand
    {
        public override string Trigger
        {
            get { return "dry"; }
        }

        public override string Description
        {
            get { return "Simulates generating files without writing to disk"; }
        }

        public override string Example
        {
            get { return "entitas dry"; }
        }

        public override void Execute(string[] args)
        {
            if (AssertProperties())
            {
                var codeGenerator = CodeGeneratorUtil.CodeGeneratorFromProperties();

                codeGenerator.OnProgress += (title, info, progress) =>
                {
                    var p = (int) (progress * 100);
                    Log.I("{0}: {1} ({2}%)", title, info, p);
                };

                codeGenerator.DryRun();
            }
        }
    }
}