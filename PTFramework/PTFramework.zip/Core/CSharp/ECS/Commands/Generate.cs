﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework
{
    using PTGame.Framework.CodeGeneration.CodeGenerator;

    public class Generate : ECSCommand
    {

        public override string Trigger
        {
            get { return "gen"; }
        }

        public override string Description
        {
            get { return "Generates files based on PTGame.Framework.properties"; }
        }

        public override string Example
        {
            get { return "entitas gen"; }
        }

        public override void Execute(string[] args)
        {
            if (AssertProperties())
            {
                var codeGenerator = CodeGeneratorUtil.CodeGeneratorFromProperties();

                codeGenerator.OnProgress += (title, info, progress) =>
                {
                    var p = (int) (progress * 100);
                    Log.I(string.Format("{0}: {1} ({2}%)", title, info, p));
                };

                codeGenerator.Generate();
            }
        }
    }
}