﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework
{
    using System.IO;
    using PTGame.Framework;

    public abstract class ECSCommand : ICommand<string[]>
    {
        public abstract string Trigger { get; }
        public abstract string Description { get; }
        public abstract string Example { get; }

        public virtual void Execute(string[] args){}

        protected Properties LoadProperties()
        {
            return new Properties(File.ReadAllText(Preferences.PATH));
        }

        protected bool AssertProperties()
        {
            if (File.Exists(Preferences.PATH))
            {
                return true;
            }

            Log.W("Couldn't find " + Preferences.PATH);
            Log.I("Run 'entitas new' to create PTGame.Framework.properties with default values");

            return false;
        }
    }
}