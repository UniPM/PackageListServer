﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework.CodeGeneration.CodeGenerator.CLI
{
    
    using PTGame.Framework;
    
    public class EditConfig : ECSCommand
    {
        public override string Trigger
        {
            get { return "edit"; }
        }

        public override string Description
        {
            get { return "Opens PTGame.Framework.properties config"; }
        }

        public override string Example
        {
            get { return "entitas edit"; }
        }

        public override void Execute(string[] args)
        {
            if (AssertProperties())
            {
                Log.I("Opening " + Preferences.PATH);
                System.Diagnostics.Process.Start(Preferences.PATH);
            }
        }
    }
}