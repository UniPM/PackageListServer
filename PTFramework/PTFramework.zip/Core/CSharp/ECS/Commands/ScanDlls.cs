﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework.CodeGeneration.CodeGenerator.CLI
{
    using System;
    using System.Linq;
    using PTGame.Framework;

    public class ScanDlls : ECSCommand
    {
        public override string Trigger
        {
            get { return "scan"; }
        }

        public override string Description
        {
            get { return "Scans and prints available types found in specified assemblies"; }
        }

        public override string Example
        {
            get { return "entitas scan"; }
        }

        public override void Execute(string[] args)
        {
            if (AssertProperties())
            {
                PrintTypes(CodeGeneratorUtil.LoadTypesFromPlugins(LoadProperties()));
            }
        }

        static void PrintTypes(Type[] types)
        {
            types.OrderBy(type => type.Assembly.GetName().Name)
                .ThenBy(type => type.FullName)
                .ToList()
                .ForEach(type => Log.I("{0}:{1}", type.Assembly.GetName().Name, type));
        }
    }
}