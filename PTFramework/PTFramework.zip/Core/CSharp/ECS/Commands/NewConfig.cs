﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework.CodeGeneration.CodeGenerator.CLI
{
    using System.IO;
    
    using PTGame.Framework;

    public class NewConfig : ECSCommand
    {
        public override string Trigger
        {
            get { return "new"; }
        }

        public override string Description
        {
            get { return "Creates new PTGame.Framework.properties config with default values"; }
        }

        public override string Example
        {
            get { return "entitas new [-f]"; }
        }

        public override void Execute(string[] args)
        {
            var currentDir = Directory.GetCurrentDirectory();
            var path = currentDir + Path.DirectorySeparatorChar + Preferences.PATH;

            if ( /*args.IsForce() ||*/ !File.Exists(path))
            {
                var defaultConfig = new CodeGeneratorConfig();
                var properties = new Properties(defaultConfig.DefaultProperties);
                defaultConfig.Configure(properties);

                var propertiesString = defaultConfig.ToString();
                File.WriteAllText(path, propertiesString);

                Log.I("Created " + path);
                Log.I(propertiesString);

                new EditConfig().Execute(args);
            }
            else
            {
                Log.W(path + " already exists!");
                Log.I("Use entitas new -f to overwrite the exiting file.");
                Log.I("Use entitas edit to open the exiting file.");
            }
        }
    }
}