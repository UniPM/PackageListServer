﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework.CodeGeneration.CodeGenerator.CLI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    
    using PTGame.Framework;

    public class Status : ECSCommand
    {
        public override string Trigger
        {
            get { return "status"; }
        }

        public override string Description
        {
            get { return "Lists available and unavailable plugins"; }
        }

        public override string Example
        {
            get { return "entitas status"; }
        }

        public override void Execute(string[] args)
        {
            if (AssertProperties())
            {
                var properties = LoadProperties();
                var config = new CodeGeneratorConfig();
                config.Configure(properties);

                Log.I(config.ToString());

                Type[] types = null;
                Dictionary<string, string> configurables = null;

                try
                {
                    types = CodeGeneratorUtil.LoadTypesFromPlugins(properties);
                    configurables = CodeGeneratorUtil.GetConfigurables(
                        CodeGeneratorUtil.GetUsed<ICodeGeneratorDataProvider>(types, config.DataProviders),
                        CodeGeneratorUtil.GetUsed<ICodeGenerator>(types, config.CodeGenerators),
                        CodeGeneratorUtil.GetUsed<ICodeGenFilePostProcessor>(types, config.PostProcessors)
                    );

                }
                catch (Exception ex)
                {
                    PrintKeyStatus(config.DefaultProperties.Keys.ToArray(), properties);
                    throw ex;
                }

                var requiredKeys = config.DefaultProperties.Merge(configurables).Keys.ToArray();

                PrintKeyStatus(requiredKeys, properties);
                PrintPluginStatus(types, config);
            }
        }

        static void PrintKeyStatus(string[] requiredKeys, Properties properties)
        {
            Helper.GetUnusedKeys(requiredKeys, properties).ForEach(key => Log.I("unused Key:{0}", key));
            Helper.GetMissingKeys(requiredKeys, properties).ForEach(key => Log.I("Missing key: {0}", key));
        }

        static void PrintPluginStatus(Type[] types, CodeGeneratorConfig config)
        {
            var unavailableDataProviders =
                CodeGeneratorUtil.GetUnavailable<ICodeGeneratorDataProvider>(types, config.DataProviders);
            var unavailableCodeGenerators =
                CodeGeneratorUtil.GetUnavailable<ICodeGenerator>(types, config.CodeGenerators);
            var unavailablePostProcessors =
                CodeGeneratorUtil.GetUnavailable<ICodeGenFilePostProcessor>(types, config.PostProcessors);

            var availableDataProviders =
                CodeGeneratorUtil.GetAvailable<ICodeGeneratorDataProvider>(types, config.DataProviders);
            var availableCodeGenerators = CodeGeneratorUtil.GetAvailable<ICodeGenerator>(types, config.CodeGenerators);
            var availablePostProcessors =
                CodeGeneratorUtil.GetAvailable<ICodeGenFilePostProcessor>(types, config.PostProcessors);

            PrintUnavailable(unavailableDataProviders);
            PrintUnavailable(unavailableCodeGenerators);
            PrintUnavailable(unavailablePostProcessors);

            PrintAvailable(availableDataProviders);
            PrintAvailable(availableCodeGenerators);
            PrintAvailable(availablePostProcessors);
        }

        static void PrintUnavailable(string[] names)
        {
            names.ForEach(name => Log.I("Unavailable: {0}", name));
        }

        static void PrintAvailable(string[] names)
        {
            names.ForEach(name => Log.I("Available: {0}", name));
        }
    }
}