﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework
{
    using PTGame.Framework;
    using PTGame.Framework.CodeGeneration.CodeGenerator.CLI;
    using PTGame.Framework.CodeGeneration.CodeGenerator;

    public class Doctor : ECSCommand
    {
        public override string Trigger
        {
            get { return "doctor"; }
        }

        public override string Description
        {
            get { return "Checks the config for potential problems"; }
        }

        public override string Example
        {
            get { return "entitas doctor"; }
        }

        public override void Execute(string[] args)
        {
            Log.I("PTGame.Framework Code Generator version " + EntitasResources.GetVersion());
            if (AssertProperties())
            {
                new Status().Execute(args);

                Log.I("Dry Run");

                CodeGeneratorUtil
                    .CodeGeneratorFromProperties()
                    .DryRun();
            }
        }
    }
}