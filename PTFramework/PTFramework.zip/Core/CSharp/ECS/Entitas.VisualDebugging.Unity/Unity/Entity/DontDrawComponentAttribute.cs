﻿using System;

namespace PTGame.Framework.VisualDebugging.Unity {

    [AttributeUsage(AttributeTargets.Class)]
    public class DontDrawComponentAttribute : Attribute {
    }
}
