﻿using UnityEngine;

namespace PTGame.Framework.VisualDebugging.Unity
{
    public class DebugSystemsBehaviour : MonoBehaviour
    {
        public DebugSystems Systems { get; protected set; }


        public void Init(DebugSystems systems)
        {
            Systems = systems;
        }
    }
}