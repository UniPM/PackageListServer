﻿using System;

namespace PTGame.Framework.VisualDebugging.Unity.Editor {

    public interface IDefaultInstanceCreator {

        bool HandlesType(Type type);

        object CreateDefault(Type type);
    }
}
