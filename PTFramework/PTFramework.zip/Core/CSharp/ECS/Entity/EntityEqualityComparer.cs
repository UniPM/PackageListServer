﻿using System.Collections.Generic;
using PTGame.Framework;

namespace PTGame.Framework
{

    public class EntityEqualityComparer<TEntity> : IEqualityComparer<TEntity> where TEntity : class, IEntity
    {
        public static readonly IEqualityComparer<TEntity> Comparer = new EntityEqualityComparer<TEntity>();

        public bool Equals(TEntity x, TEntity y)
        {
            return x == y;
        }

        public int GetHashCode(TEntity obj)
        {
            return obj.CreationIndex;
        }
    }
}