﻿namespace PTGame.Framework
{
    public interface IReactiveSystem : IExecuteSystem
    {
        void Activate();
        void Deactivate();
        void Clear();
    }
}