﻿using PTGame.Framework;

namespace PTGame.Framework.CodeGeneration.Plugins {

    public class ContextData : CodeGeneratorData {
    }
}
