﻿using System;

namespace PTGame.Framework.CodeGeneration.Plugins {

    public interface IComponentDataProvider {

        void Provide(Type type, ComponentData data);
    }
}
