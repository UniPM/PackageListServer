﻿using System.IO;
using System.Linq;
using PTGame.Framework;

namespace PTGame.Framework.CodeGeneration.Plugins
{

    public class ContextGenerator : ICodeGenerator
    {

        public string Name
        {
            get { return "Context"; }
        }

        public int Priority
        {
            get { return 0; }
        }

        public bool IsEnabledByDefault
        {
            get { return true; }
        }

        public bool RunInDryMode
        {
            get { return true; }
        }

        const string CONTEXT_TEMPLATE =
            @"public sealed partial class ${ContextName}Context : PTGame.Framework.Context<${ContextName}Entity> 
  {

    public ${ContextName}Context()
        : base(
            ${Lookup}.TotalComponents,
            0,
            new PTGame.Framework.ContextInfo(
                ""${ContextName}"",
                ${Lookup}.componentNames,
                ${Lookup}.componentTypes
            ),
            (entity) =>

#if (ENTITAS_FAST_AND_UNSAFE)
                new PTGame.Framework.UnsafeARC()
#else
                new PTGame.Framework.SafeARC(entity)
#endif

        ) {
    }
}
";

        public CodeGenFile[] Generate(CodeGeneratorData[] data)
        {
            return data
                .OfType<ContextData>()
                .Select(d => generateContextClass(d))
                .ToArray();
        }

        CodeGenFile generateContextClass(ContextData data)
        {
            var contextName = data.GetContextName();
            return new CodeGenFile(
                contextName + Path.DirectorySeparatorChar + contextName + "Context.cs",
                CONTEXT_TEMPLATE
                    .Replace("${ContextName}", contextName)
                    .Replace("${Lookup}", contextName + ComponentsLookupGenerator.COMPONENTS_LOOKUP),
                GetType().FullName
            );
        }
    }
}