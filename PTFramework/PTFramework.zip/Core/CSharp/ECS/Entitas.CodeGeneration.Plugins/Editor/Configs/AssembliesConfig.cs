﻿using System.Collections.Generic;
using PTGame.Framework;
using PTGame.Framework;

namespace PTGame.Framework.CodeGeneration.Plugins {

    public class AssembliesConfig : AbstractConfigurableConfig {

        const string ASSEMBLIES_KEY = "PTGame.Framework.CodeGeneration.Plugins.Assemblies";

        public override Dictionary<string, string> DefaultProperties {
            get {
                return new Dictionary<string, string> {
                    { ASSEMBLIES_KEY, "Library/ScriptAssemblies/Assembly-CSharp.dll" }
                };
            }
        }

        public string[] assemblies {
            get { return Properties[ASSEMBLIES_KEY].ArrayFromCSV(); }
        }
    }
}