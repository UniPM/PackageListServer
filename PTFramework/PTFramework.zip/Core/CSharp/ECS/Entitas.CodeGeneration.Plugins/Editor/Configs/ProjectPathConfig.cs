﻿using System.Collections.Generic;
using PTGame.Framework;

namespace PTGame.Framework.CodeGeneration.Plugins {

    public class ProjectPathConfig : AbstractConfigurableConfig {

        const string PROJECT_PATH_KEY = "PTGame.Framework.CodeGeneration.Plugins.ProjectPath";

        public override Dictionary<string, string> DefaultProperties {
            get {
                return new Dictionary<string, string> {
                    { PROJECT_PATH_KEY, "Assembly-CSharp.csproj" }
                };
            }
        }

        public string projectPath {
            get { return Properties[PROJECT_PATH_KEY]; }
        }
    }
}
