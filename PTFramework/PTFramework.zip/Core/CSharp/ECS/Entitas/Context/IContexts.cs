﻿namespace PTGame.Framework {

    public interface IContexts {

        IContext[] allContexts { get; }
    }
}
