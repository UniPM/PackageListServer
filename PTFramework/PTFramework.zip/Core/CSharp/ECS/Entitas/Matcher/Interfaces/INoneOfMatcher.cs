﻿using PTGame.Framework;

namespace PTGame.Framework {

    public interface INoneOfMatcher<TEntity> : ICompoundMatcher<TEntity> where TEntity : class, IEntity {
    }
}
