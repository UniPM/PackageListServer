﻿namespace PTGame.Framework {

    public enum GroupEvent : byte {
        Added,
        Removed,
        AddedOrRemoved
    }
}
