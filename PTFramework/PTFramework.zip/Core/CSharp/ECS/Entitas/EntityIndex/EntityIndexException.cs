﻿using PTGame.Framework;

namespace PTGame.Framework {

    public class EntityIndexException : ExceptionWithHint {

        public EntityIndexException(string message, string hint)
            : base(message, hint) {
        }
    }
}
