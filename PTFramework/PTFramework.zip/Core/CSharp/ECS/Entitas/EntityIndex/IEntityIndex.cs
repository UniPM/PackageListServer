﻿namespace PTGame.Framework {

    public interface IEntityIndex {

        string Name { get; }

        void Activate();
        void Deactivate();
    }
}
