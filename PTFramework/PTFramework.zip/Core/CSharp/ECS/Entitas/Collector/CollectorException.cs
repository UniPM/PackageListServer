﻿using PTGame.Framework;

namespace PTGame.Framework {

    public class CollectorException : ExceptionWithHint {

        public CollectorException(string message, string hint)
            : base(message, hint) {
        }
    }
}
