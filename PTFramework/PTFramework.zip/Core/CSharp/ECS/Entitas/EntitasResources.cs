﻿using System.IO;

namespace PTGame.Framework
{

    public static class EntitasResources
    {

        public static string GetVersion()
        {
            var assembly = typeof(Entity).Assembly;
            var stream = assembly.GetManifestResourceStream("version");
            var version = "";
            using (var reader = new StreamReader(stream))
            {
                version = reader.ReadToEnd();
            }

            return version;
        }
    }
}
