﻿using System.Collections.Generic;

namespace PTGame.Framework
{
    public interface IConfigurable
    {
        Dictionary<string, string> DefaultProperties { get; }

        void Configure(Properties properties);
    }
}