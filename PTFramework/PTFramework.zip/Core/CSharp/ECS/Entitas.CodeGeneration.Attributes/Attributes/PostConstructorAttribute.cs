﻿using System;

namespace PTGame.Framework.CodeGeneration.Attributes
{
    [AttributeUsage(AttributeTargets.Method)]
    public class PostConstructorAttribute : Attribute
    {
    }
}