﻿using System;

namespace PTGame.Framework.CodeGeneration.Attributes
{
    [AttributeUsage(AttributeTargets.Method)]
    public class EntityIndexGetMethodAttribute : Attribute
    {
    }
}