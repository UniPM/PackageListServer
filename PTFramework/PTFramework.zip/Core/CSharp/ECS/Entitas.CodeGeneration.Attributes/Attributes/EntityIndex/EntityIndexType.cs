﻿namespace PTGame.Framework.CodeGeneration.Attributes
{
    public enum EntityIndexType
    {
        EntityIndex,
        PrimaryEntityIndex
    }
}