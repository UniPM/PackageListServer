﻿using System;

namespace PTGame.Framework.CodeGeneration.Attributes
{
    [AttributeUsage(AttributeTargets.Interface | AttributeTargets.Class | AttributeTargets.Struct)]
    public class UniqueAttribute : Attribute
    {
    }
}