﻿using UnityEditor;
using UnityEngine;

namespace PTGame.Framework {

    public static class EntitasMenuItems {
        
        public const string preferences                      = "Tools/PTGame.Framework/Preferences... #%e";

        public const string check_for_updates                = "Tools/PTGame.Framework/Check for Updates...";

        public const string documentation                    = "Tools/PTGame.Framework/Documentation...";

        public const string feedback_report_a_bug            = "Tools/PTGame.Framework/Feedback/Report a bug...";
        public const string feedback_request_a_feature       = "Tools/PTGame.Framework/Feedback/Request a feature...";
        public const string feedback_join_the_entitas_chat   = "Tools/PTGame.Framework/Feedback/Join the PTGame.Framework chat...";
        public const string feedback_entitas_wiki            = "Tools/PTGame.Framework/Feedback/PTGame.Framework Wiki...";
        public const string feedback_donate                  = "Tools/PTGame.Framework/Feedback/Donate...";
    }

    public static class EntitasMenuItemPriorities {

        public const int preferences                         = 1;

        public const int check_for_updates                   = 10;

        public const int documentation                       = 11;

        public const int feedback_report_a_bug               = 20;
        public const int feedback_request_a_feature          = 21;
        public const int feedback_join_the_entitas_chat      = 22;
        public const int feedback_entitas_wiki               = 23;
        public const int feedback_donate                     = 24;
    }

    public static class EntitasFeedback {

        [MenuItem(EntitasMenuItems.documentation, false, EntitasMenuItemPriorities.documentation)]
        public static void EntitasDocs() {
            Application.OpenURL("http://sschmid.github.io/PTGame.Framework-CSharp/");
        }

        [MenuItem(EntitasMenuItems.feedback_report_a_bug, false, EntitasMenuItemPriorities.feedback_report_a_bug)]
        public static void ReportBug() {
            Application.OpenURL("https://github.com/sschmid/PTGame.Framework-CSharp/issues");
        }

        [MenuItem(EntitasMenuItems.feedback_request_a_feature, false, EntitasMenuItemPriorities.feedback_request_a_feature)]
        public static void RequestFeature() {
            Application.OpenURL("https://github.com/sschmid/PTGame.Framework-CSharp/issues");
        }

        [MenuItem(EntitasMenuItems.feedback_join_the_entitas_chat, false, EntitasMenuItemPriorities.feedback_join_the_entitas_chat)]
        public static void EntitasChat() {
            Application.OpenURL("https://gitter.im/sschmid/PTGame.Framework-CSharp");
        }

        [MenuItem(EntitasMenuItems.feedback_entitas_wiki, false, EntitasMenuItemPriorities.feedback_entitas_wiki)]
        public static void EntitasWiki() {
            Application.OpenURL("https://github.com/sschmid/PTGame.Framework-CSharp/wiki");
        }

        [MenuItem(EntitasMenuItems.feedback_donate, false, EntitasMenuItemPriorities.feedback_donate)]
        public static void Donate() {
            Application.OpenURL("https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=BTMLSDQULZ852");
        }
    }
}
