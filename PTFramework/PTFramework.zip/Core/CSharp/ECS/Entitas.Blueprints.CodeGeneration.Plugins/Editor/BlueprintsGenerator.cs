﻿using System.Linq;
using PTGame.Framework;

namespace PTGame.Framework.Blueprints.CodeGeneration.Plugins
{
    public class BlueprintsGenerator : ICodeGenerator
    {

        public string Name
        {
            get { return "Blueprint"; }
        }

        public int Priority
        {
            get { return 0; }
        }

        public bool IsEnabledByDefault
        {
            get { return true; }
        }

        public bool RunInDryMode
        {
            get { return true; }
        }

        const string CLASS_TEMPLATE =
            @"using PTGame.Framework.Blueprints;
using PTGame.Framework.Blueprints.Unity;

public static class BlueprintsExtension {

${blueprints}
}
";

        const string GETTER_TEMPLATE =
            @"    public static Blueprint ${ValidPropertyName}(this Blueprints blueprints) {
        return blueprints.GetBlueprint(""${Name}"");
    }";

        public CodeGenFile[] Generate(CodeGeneratorData[] data)
        {
            var blueprintNames = data
                .OfType<BlueprintData>()
                .Select(d => d.GetBlueprintName())
                .OrderBy(name => name)
                .ToArray();

            if (blueprintNames.Length == 0)
            {
                return new CodeGenFile[0];
            }

            var blueprints = CLASS_TEMPLATE.Replace("${blueprints}", generateBlueprintGetters(blueprintNames));
            return new[]
            {
                new CodeGenFile(
                    "GeneratedBlueprints.cs",
                    blueprints,
                    GetType().FullName)
            };
        }

        string generateBlueprintGetters(string[] blueprintNames)
        {
            return string.Join("\n", blueprintNames
                .Select(name => GETTER_TEMPLATE
                    .Replace("${ValidPropertyName}", validPropertyName(name))
                    .Replace("${Name}", name))
                .ToArray());
        }

        static string validPropertyName(string name)
        {
            return name
                .Replace(" ", string.Empty)
                .Replace("-", string.Empty)
                .Replace("(", string.Empty)
                .Replace(")", string.Empty);
        }
    }
}