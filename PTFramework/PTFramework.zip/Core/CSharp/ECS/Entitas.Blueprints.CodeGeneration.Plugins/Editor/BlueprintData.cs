﻿using PTGame.Framework.CodeGeneration;
using PTGame.Framework;

namespace PTGame.Framework.Blueprints.CodeGeneration.Plugins
{
    public class BlueprintData : CodeGeneratorData
    {
    }
}