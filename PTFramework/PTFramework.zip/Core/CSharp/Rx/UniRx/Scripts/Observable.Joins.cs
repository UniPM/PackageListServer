﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PTGame.Framework
{
    public static partial class Observable
    {
    }
}
