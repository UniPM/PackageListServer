﻿// this code is borrowed from RxOfficial(rx.codeplex.com) and modified

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace PTGame.Framework
{
    internal class PriorityQueue<T> where T : IComparable<T>
    {
        private static long mCount = long.MinValue;

        private IndexedItem[] mItems;
        private int mSize;

        public PriorityQueue()
            : this(16)
        {
        }

        public PriorityQueue(int capacity)
        {
            mItems = new IndexedItem[capacity];
            mSize = 0;
        }

        private bool IsHigherPriority(int left, int right)
        {
            return mItems[left].CompareTo(mItems[right]) < 0;
        }

        private void Percolate(int index)
        {
            if (index >= mSize || index < 0)
                return;
            var parent = (index - 1) / 2;
            if (parent < 0 || parent == index)
                return;

            if (IsHigherPriority(index, parent))
            {
                var temp = mItems[index];
                mItems[index] = mItems[parent];
                mItems[parent] = temp;
                Percolate(parent);
            }
        }

        private void Heapify()
        {
            Heapify(0);
        }

        private void Heapify(int index)
        {
            if (index >= mSize || index < 0)
                return;

            var left = 2 * index + 1;
            var right = 2 * index + 2;
            var first = index;

            if (left < mSize && IsHigherPriority(left, first))
                first = left;
            if (right < mSize && IsHigherPriority(right, first))
                first = right;
            if (first != index)
            {
                var temp = mItems[index];
                mItems[index] = mItems[first];
                mItems[first] = temp;
                Heapify(first);
            }
        }

        public int Count { get { return mSize; } }

        public T Peek()
        {
            if (mSize == 0)
                throw new InvalidOperationException("HEAP is Empty");

            return mItems[0].Value;
        }

        private void RemoveAt(int index)
        {
            mItems[index] = mItems[--mSize];
            mItems[mSize] = default(IndexedItem);
            Heapify();
            if (mSize < mItems.Length / 4)
            {
                var temp = mItems;
                mItems = new IndexedItem[mItems.Length / 2];
                Array.Copy(temp, 0, mItems, 0, mSize);
            }
        }

        public T Dequeue()
        {
            var result = Peek();
            RemoveAt(0);
            return result;
        }

        public void Enqueue(T item)
        {
            if (mSize >= mItems.Length)
            {
                var temp = mItems;
                mItems = new IndexedItem[mItems.Length * 2];
                Array.Copy(temp, mItems, temp.Length);
            }

            var index = mSize++;
            mItems[index] = new IndexedItem { Value = item, Id = Interlocked.Increment(ref mCount) };
            Percolate(index);
        }

        public bool Remove(T item)
        {
            for (var i = 0; i < mSize; ++i)
            {
                if (EqualityComparer<T>.Default.Equals(mItems[i].Value, item))
                {
                    RemoveAt(i);
                    return true;
                }
            }

            return false;
        }

        struct IndexedItem : IComparable<IndexedItem>
        {
            public T Value;
            public long Id;

            public int CompareTo(IndexedItem other)
            {
                var c = Value.CompareTo(other.Value);
                if (c == 0)
                    c = Id.CompareTo(other.Id);
                return c;
            }
        }
    }
}