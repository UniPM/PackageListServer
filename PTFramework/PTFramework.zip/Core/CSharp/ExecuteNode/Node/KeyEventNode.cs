﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
****************************************************************************/

namespace PTGame.Framework 
{
	public class KeyEventNode : EventNode
	{
		TimelineNode mTimelineNode;
		string mKeyEventName;

		public KeyEventNode(string keyEventName, TimelineNode timelineNode)
		{
			mTimelineNode = timelineNode;
			mKeyEventName = keyEventName;
		}

		protected override void OnExecute(float dt)
		{
			mTimelineNode.OnKeyEventsReceivedCallback(mKeyEventName);
			Finished = true;
		}

		protected override void OnDispose()
		{
			mTimelineNode = null;
			mKeyEventName = null;
		}
	}
}

