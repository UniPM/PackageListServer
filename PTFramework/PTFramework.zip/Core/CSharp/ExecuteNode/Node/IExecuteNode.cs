﻿/****************************************************************************
 * Copyright (c) 2017 snowcold
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework
{
    using System;
    using Internal;

    /// <summary>
    /// 执行节点的基类
    /// </summary>
    public interface IExecuteNode : INode, IExecutable<float>, IDisposable,IResetable
    {
        void Reset();

        void Break();
        
        bool Finished { get; }
    }
}