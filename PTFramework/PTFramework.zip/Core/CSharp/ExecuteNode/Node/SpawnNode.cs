﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
****************************************************************************/

namespace PTGame.Framework 
{
	using System;
	using System.Linq;
	using System.Collections.Generic;
	
	/// <summary>
	/// 并发执行的协程
	/// </summary>
	public class SpawnNode :ExecuteNode 
	{
		protected List<IExecuteNode> mNodeList = new List<IExecuteNode>();

		protected override void OnReset()
		{
			foreach (var executeNode in mNodeList)
			{
				executeNode.Reset();
			}
		}
		
		protected override void OnExecute(float dt)
		{
			foreach (var node in mNodeList.Where(node => !node.Finished))
			{
				if (node.Execute(dt))
				{
					Finished = mNodeList.Where(n => !n.Finished).Count() == 0;
				}
			}
		}
		
		public SpawnNode(params IExecuteNode[] nodes)
		{
			mNodeList.AddRange (nodes);
		}

//		[Obsolete("Deprecated since 0.0.5")]
//		public SpawnNode(object deprecated,params IExecuteNode[] nodes)
//		{
//			mNodeList.AddRange (nodes);
//		}
		
		protected override void OnDispose()
		{
			foreach (var node in mNodeList)
			{
				node.Dispose();
			}
			mNodeList.Clear();
			mNodeList = null;
		}
	}
}