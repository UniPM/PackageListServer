﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PTInputScene : MonoBehaviour {

	public InputField inputField;
	public Toggle toggle;

	private const string key_serverip = "key_serverip";
	// Use this for initialization
	void Start () {
	
		PTGlobal.serverIp = PlayerPrefs.GetString (key_serverip,"localhost");

		inputField.text = PTGlobal.serverIp;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void OnFinishEdit(string content){
		
		PTGlobal.serverIp = inputField.text.Trim ();
		Debug.Log (PTGlobal.serverIp+": >>>>content>>>");
		PlayerPrefs.SetString (key_serverip,PTGlobal.serverIp);
	}

	public void OnToggleChanged(bool value){
	
		PTGlobal.isWifiEnable= toggle.isOn;
		Debug.Log (toggle.isOn+">>>>>>>value *********");
	}
	public void StartGame(){

		UnityEngine.SceneManagement.SceneManager.LoadScene ("client");
	}
}
