﻿using UnityEngine;
using System.Collections;

public class PTGlobal {

	public static string serverIp;
	public static bool isWifiEnable= true;
}
