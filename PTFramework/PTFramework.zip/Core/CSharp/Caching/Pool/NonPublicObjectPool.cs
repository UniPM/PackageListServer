/****************************************************************************
 * Copyright (c) 2017 ouyanggongping@putao.com
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework
{
	using UnityEngine;

	/// <summary>
	/// Object pool 4 class who no public constructor
	/// such as SingletonClass.PTEventSystem
	/// </summary>
	public class NonPublicObjectPool<T> :Pool<T>,ISingleton where T : class,IPoolAble
	{
		#region Singleton
		public void OnSingletonInit(){}
		
		public static NonPublicObjectPool<T> Instance
		{
			get { return PTSingletonProperty<NonPublicObjectPool<T>>.Instance; }
		}

		protected NonPublicObjectPool()
		{
			mFactory = new NonPublicObjectFactory<T>();
		}
		public void Dispose()
		{
			PTSingletonProperty<NonPublicObjectPool<T>>.Dispose();
		}
		#endregion

		/// <summary>
		/// Init the specified maxCount and initCount.
		/// </summary>
		/// <param name="maxCount">Max Cache count.</param>
		/// <param name="initCount">Init Cache count.</param>
		public void Init(int maxCount, int initCount)
		{
			if (maxCount > 0)
			{
				initCount = Mathf.Min(maxCount, initCount);
			}

			if (CurCount < initCount)
			{
				for (int i = CurCount; i < initCount; ++i)
				{
					Recycle(mFactory.Create());
				}
			}
		}

		/// <summary>
		/// Gets or sets the max cache count.
		/// </summary>
		/// <value>The max cache count.</value>
		public int MaxCacheCount
		{
			get { return mMaxCount; }
			set
			{
				mMaxCount = value;

				if (mCacheStack != null)
				{
					if (mMaxCount > 0)
					{
						if (mMaxCount < mCacheStack.Count)
						{
							int removeCount = mMaxCount - mCacheStack.Count;
							while (removeCount > 0)
							{
								mCacheStack.Pop();
								--removeCount;
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// Allocate T instance.
		/// </summary>
		public override T Allocate()
		{
			T result = base.Allocate();
			result.IsRecycled = false;
			return result;
		}

		/// <summary>
		/// Recycle the T instance
		/// </summary>
		/// <param name="t">T.</param>
		public override bool Recycle(T t)
		{
			if (t == null || t.IsRecycled)
			{
				return false;
			}

			if (mMaxCount > 0)
			{
				if (mCacheStack.Count >= mMaxCount)
				{
					t.OnRecycled();
					return false;
				}
			}

			t.IsRecycled = true;
			t.OnRecycled();
			mCacheStack.Push(t);

			return true;
		}
	}
}