﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework
{
    public interface IObjectFactory<T>
    {
        T Create();
    }
}