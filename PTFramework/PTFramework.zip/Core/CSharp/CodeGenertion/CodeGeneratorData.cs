﻿using System.Collections.Generic;

namespace PTGame.Framework
{
    public class CodeGeneratorData : Dictionary<string, object>
    {
    }
}