﻿
namespace PTGame.Framework
{
    public interface ICodeGeneratorInterface
    {
        string Name { get; }
        
        int Priority { get; }
        
        bool IsEnabledByDefault { get; }

        bool RunInDryMode { get; }
    }
}