﻿/****************************************************************************
 * Copyright (c) 2017 ouyanggongping@putao.com
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework
{
    public interface IData
    {
        #region 数据结构学习网站
        /*
     	* http://zh.visualgo.net/
     	*/
        #endregion

        int Value
        {
            get;
        }
    }
}

