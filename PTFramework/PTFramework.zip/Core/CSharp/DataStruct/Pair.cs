﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 *
 * 参考《深入理解 C#》 P71 代码清单3-6 表示一对值的泛型类
 ****************************************************************************/

namespace PTGame.Framework
{
    using System;
    using System.Collections.Generic;

    public sealed class Pair<T1, T2> : IEquatable<Pair<T1, T2>>
    {
        private static readonly IEqualityComparer<T1> mFirstComparer = EqualityComparer<T1>.Default;
        private static readonly IEqualityComparer<T2> mSecondComparer = EqualityComparer<T2>.Default;

        private readonly T1 mFirst;
        private readonly T2 mSecond;

        public Pair(T1 first, T2 second)
        {
            mFirst = first;
            mSecond = second;
        }

        public T1 First
        {
            get { return mFirst; }
        }

        public T2 Second
        {
            get { return mSecond; }
        }

        public bool Equals(Pair<T1, T2> other)
        {
            return null != other &&
                   mFirstComparer.Equals(First, other.First) &&
                   mSecondComparer.Equals(Second, other.Second);
        }

        public override bool Equals(object o)
        {
            return Equals(o as Pair<T1, T2>);
        }

        public override int GetHashCode()
        {
            return mFirstComparer.GetHashCode(mFirst) * 37 + mSecondComparer.GetHashCode(mSecond);
        }
    }
}