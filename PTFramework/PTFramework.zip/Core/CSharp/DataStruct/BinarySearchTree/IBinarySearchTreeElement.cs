﻿/****************************************************************************
 * Copyright (c) 2017 ouyanggongping@putao.com
 * Copyright (c) 2017 liqingyun@putao.com
****************************************************************************/

namespace PTGame.Framework
{
    public interface IBinarySearchTreeElement
    {
        float SortScore
        {
            get;
        }
    }
}


