﻿/****************************************************************************
 * Copyright (c) 2017 ouyanggongping@putao.com
 * Copyright (c) 2017 liqingyun@putao.com
****************************************************************************/

namespace PTGame.Framework
{
	using System;

    public class LinkedListTest : BaseTestUnit
    {
        public override void StartTest()
        {
            TestInt();
            TestString();
        }

#region String Test
        private void TestString()
        {
            WriteBegin("LinkListTest(String)");
            PTLinkedList<string> list = new PTLinkedList<string>();
            BuildStringLinkedListRandom(list, 0, 10);
            BuildStringLinkedListRandom(list, 11, 20);
            RemoveListAtIndex(list, 19);
            RemoveListAtIndex(list, 0);
            RemoveData(list, "Index:7");
            VisitList(list);
            FindData(list, "Index:9");
            WriteEnd("LinkListTest(String)");
        }

        private void BuildStringLinkedListRandom(PTLinkedList<string> list, int start, int end)
        {
            for (int i = start; i <= end; ++i)
            {
                list.InsertTail(string.Format("Index:{0}", i));
            }
            WriteLine("Build:[{0}:{1}]", start, end);
        }
#endregion

#region Int Test
        private void TestInt()
        {
            WriteBegin("LinkListTest(Int)");
            PTLinkedList<int> list = new PTLinkedList<int>();
            BuildIntLinkedListRandom(list, 0, 10);
            BuildIntLinkedListRandom(list, 11, 20);
            RemoveListAtIndex(list, 19);
            RemoveListAtIndex(list, 0);
            RemoveData(list, 7);
            VisitList(list);
            FindData(list, 9);
            WriteEnd("LinkListTest(Int)");
        }

        private void BuildIntLinkedListRandom(PTLinkedList<int> list, int start, int end)
        {
            for (int i = start; i <= end; ++i)
            {
                list.InsertTail(i);
            }
            WriteLine("Build:[{0}:{1}]", start, end);
        }
#endregion

        private void RemoveListAtIndex<T>(PTLinkedList<T> list, int index)
        {
            WriteLine("Remove At:{0}-Result:{1}", index, list.RemoveAt(index));
        }

        private void RemoveData<T>(PTLinkedList<T> list, T data)
        {
            WriteLine("Remove Data:{0}-Result:{1}", data, list.Remove(data));
        }

        private void VisitList<T>(PTLinkedList<T> list)
        {
            WriteLine("Data Begin:");
            list.Accept(VisitData);
            WriteLine("");
        }

        protected void FindData<T>(PTLinkedList<T> list, T data)
        {
            WriteLine("FindData{0}: Result:{1}", data, list.Query(data));
        }

        protected void VisitData<T>(T data)
        {
            if (data != null)
            {
                Write(string.Format("   {0}", data));
            }
            else
            {
                Write(" NULL ");
            }
        }
    }
}


