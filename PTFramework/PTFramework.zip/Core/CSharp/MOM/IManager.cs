﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 * https://github.com/CoolYiWen/MOMFrame
 * https://github.com/zhutaorun
 * https://github.com/zhutaorun/Hearth-Stone
 * https://github.com/strangeioc
 * http://www.jianshu.com/p/10693fee70a5
 * https://github.com/handcircus/Unity-Resource-Checker
 * https://github.com/JefferiesTube/UnityEditorHelper
 * https://github.com/liortal53/MissingReferencesUnity
 ****************************************************************************/

namespace PTGame.Framework
{
	/// <summary>
	/// Support Manager of Manager
	/// </summary>
	public interface IManager 
	{
		void Init();
	}
}