﻿/****************************************************************************
 * Copyright (c) 2017 liqingyun@putao.com
 ****************************************************************************/

namespace PTGame.Framework
{
    public class ObjectIsAlreadyRetainedByOwnerException : ExceptionWithHint
    {
        public ObjectIsAlreadyRetainedByOwnerException(object obj, object owner)
            : base(string.Format("'{0}' cannot retain {1}!\n" +
                                 "Object is already retained by this object!", owner, obj),
                "The entity must be released by this object first.")
        {
        }
    }
}