﻿/****************************************************************************
 * Copyright (c) 2017 zhuhaoqiao@putao.com
 ****************************************************************************/

namespace PTGame.Framework.Test.Core
{
	using NUnit.Framework;
	using Framework;

	public class FSMLiteTest 
	{
		PTFSMLite mFSMLite = new PTFSMLite ();

		[Test]
		public void FSMLiteTest_AddTranslation()
		{
			string str1 = "work->rest true";
			string str2 = "work->rest false";
			mFSMLite.AddState ("work");
			mFSMLite.AddState ("rest");

			mFSMLite.AddTranslation ("work", "work->rest", "rest", delegate {
				str2="work->rest true";
			});

			mFSMLite.Start ("work");

			mFSMLite.HandleEvent ("work->rest");

			Assert.IsNotNull(mFSMLite);
			Assert.AreEqual (str1, str2);
		}
	}
}
