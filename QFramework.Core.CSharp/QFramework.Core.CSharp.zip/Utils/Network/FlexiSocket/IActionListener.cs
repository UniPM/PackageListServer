

namespace QFramework
{


public interface IActionListener  
{


	void OnAction(QSimulateAction action);
}
public enum QSimulateAction{
	LEFT,
	RIGHT,
	UP,
	DOWN

}
}