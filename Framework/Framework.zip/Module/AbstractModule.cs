/****************************************************************************
 * Copyright (c) 2017 snowcold
 * Copyright (c) 2017 liangxie
****************************************************************************/

namespace QFramework
{
    public class AbstractModule : AbstractActorComponent, IModule
    {

    }
}
