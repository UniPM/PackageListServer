﻿using System;

namespace QFramework.CodeGeneration.Attributes
{
    [AttributeUsage(AttributeTargets.Method)]
    public class PostConstructorAttribute : Attribute
    {
    }
}