﻿namespace QFramework.CodeGeneration.Attributes
{
    public enum EntityIndexType
    {
        EntityIndex,
        PrimaryEntityIndex
    }
}