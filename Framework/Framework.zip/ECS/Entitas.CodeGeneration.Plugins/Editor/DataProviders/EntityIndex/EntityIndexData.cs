﻿

namespace QFramework
{
    public class EntityIndexData : CodeGeneratorData
    {
    }
}