﻿

namespace QFramework {

    public class ContextData : CodeGeneratorData {
    }
}
