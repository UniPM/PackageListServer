﻿using System;

namespace QFramework.VisualDebugging.Unity {

    [AttributeUsage(AttributeTargets.Class)]
    public class DontDrawComponentAttribute : Attribute {
    }
}
