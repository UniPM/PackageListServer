/****************************************************************************
 * Copyright (c) 2017 liangxie
****************************************************************************/

namespace QFramework
{
	using UnityEngine;
	using UnityEditor;

	public class EditorGUIUtils 
	{
		public static string GUILabelAndTextField(string labelContent,string textFieldContent,bool horizontal = true)
		{
			if (horizontal)
			EditorGUILayout.BeginHorizontal ();

			GUILayout.Label (labelContent);

			string retString = EditorGUILayout.TextField (textFieldContent);

			if (horizontal)
			EditorGUILayout.EndHorizontal();

			return retString;
		}
		

		public static int GUILabelAndPopup(string labelContent,int popupIndex,string[] popupContents)
		{
			EditorGUILayout.BeginHorizontal ();

			GUILayout.Label (labelContent);

			int retIndex = EditorGUILayout.Popup (popupIndex,popupContents);

			EditorGUILayout.EndHorizontal ();

			return retIndex;
		}
	}
}