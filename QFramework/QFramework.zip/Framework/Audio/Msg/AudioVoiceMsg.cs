/****************************************************************************
 * Copyright (c) 2017 liangxie
****************************************************************************/

namespace QFramework
{
	using  System;
	
	public class AudioVoiceMsg : QMsg
	{
		public string voiceName;
		public Action onVoiceBeganCallback;
		public Action onVoiceEndedCallback;

		/// <summary>
		/// 是否循环
		/// </summary>
		public bool loop = false;

		/// <summary>
		/// 循环间隔
		/// </summary>
		public float intervalTime = 0.0f;

		public AudioVoiceMsg()
		{
		}

		public AudioVoiceMsg(string voiceName,
			Action onVoiceBeganCallback = null,
			Action onVoiceEndedCallback = null) : base((int) AudioEvent.PlayVoice)
		{
			this.voiceName = voiceName;
			this.onVoiceBeganCallback = onVoiceBeganCallback;
			this.onVoiceEndedCallback = onVoiceEndedCallback;
		}
	}
}