/****************************************************************************
 * Copyright (c) 2017 snowcold
 * Copyright (c) 2017 liangxie
****************************************************************************/

namespace QFramework
{
    public class ComponentOrderDefine
    {
        public const int FIRST = 0;
        public const int DEFAULT = 100;
        public const int LAST = 9999;
    }
}
