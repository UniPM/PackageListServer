﻿using QFramework.CodeGeneration;


namespace QFramework.Blueprints.CodeGeneration.Plugins
{
    public class BlueprintData : CodeGeneratorData
    {
    }
}