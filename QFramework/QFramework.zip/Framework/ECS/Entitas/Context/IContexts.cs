﻿namespace QFramework {

    public interface IContexts {

        IContext[] allContexts { get; }
    }
}
