﻿namespace QFramework {

    public enum GroupEvent : byte {
        Added,
        Removed,
        AddedOrRemoved
    }
}
